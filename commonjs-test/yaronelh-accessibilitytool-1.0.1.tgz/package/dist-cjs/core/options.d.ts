import { IAccessibilityModuleOrder, IAccessibilityOptions } from '../interfaces/accessibility.interface.js';
import { Common } from '../common.js';
export declare function addDefaultIconOptions(targetOptions: IAccessibilityOptions, userOptions: IAccessibilityOptions): void;
export declare function ensureModuleOrder(defaultOrder: Array<IAccessibilityModuleOrder>, modulesOrder: Array<IAccessibilityModuleOrder>): void;
export declare function disableUnsupportedFeatures(common: Common, options: IAccessibilityOptions): void;
export declare function buildDefaultModuleOrder(): IAccessibilityModuleOrder[];
