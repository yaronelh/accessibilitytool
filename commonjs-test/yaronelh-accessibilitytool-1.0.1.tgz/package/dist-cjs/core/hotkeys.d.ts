import { IAccessibilityHotkeysOptions } from '../interfaces/accessibility.interface.js';
export declare function parseHotkeyLabel(hotkeys: IAccessibilityHotkeysOptions, hotkeyPrefix: string, arr: Array<any>): string;
export declare function findMatchingHotkey(keys: IAccessibilityHotkeysOptions['keys'], event: KeyboardEvent): [string, any];
