"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.parseHotkeyLabel = parseHotkeyLabel;
exports.findMatchingHotkey = findMatchingHotkey;
function parseHotkeyLabel(hotkeys, hotkeyPrefix, arr) {
    return hotkeys.enabled
        ? hotkeys.helpTitles
            ? hotkeyPrefix +
                arr
                    .map(function (val) {
                    return Number.isInteger(val)
                        ? String.fromCharCode(val).toLowerCase()
                        : val.replace('Key', '');
                })
                    .join('+')
            : ''
        : '';
}
function findMatchingHotkey(keys, event) {
    return Object.entries(keys).find(function (entry) {
        const [, combo] = entry;
        let matches = true;
        for (let i = 0; i < combo.length; i++) {
            if (Number.isInteger(combo[i])) {
                if (event.keyCode !== combo[i])
                    matches = false;
            }
            else if (event[combo[i]] !== true) {
                matches = false;
            }
        }
        return matches;
    });
}
//# sourceMappingURL=hotkeys.js.map