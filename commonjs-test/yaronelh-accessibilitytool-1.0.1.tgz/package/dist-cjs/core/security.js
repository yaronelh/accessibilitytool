"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.escapeCssString = escapeCssString;
exports.sanitizeDomAttribute = sanitizeDomAttribute;
exports.normalizeIframeUrl = normalizeIframeUrl;
function escapeCssString(value) {
    return String(value)
        .replace(/\\/g, '\\\\')
        .replace(/"/g, '\\"')
        .replace(/\r/g, '\\r')
        .replace(/\n/g, '\\n');
}
function sanitizeDomAttribute(tagName, attrName, attrValue) {
    const normalizedName = attrName.toLowerCase();
    if (normalizedName.startsWith('on'))
        return null;
    if ((normalizedName === 'src' || normalizedName === 'href') &&
        typeof attrValue === 'string' &&
        /^\s*javascript:/i.test(attrValue)) {
        return null;
    }
    if (tagName === 'iframe' &&
        normalizedName === 'src' &&
        typeof attrValue === 'string' &&
        /^\s*(data:|javascript:|file:)/i.test(attrValue)) {
        return null;
    }
    return String(attrValue);
}
function normalizeIframeUrl(url, allowedOrigins = []) {
    try {
        const parsed = new URL(url, window.location.href);
        const sameOrigin = parsed.origin === window.location.origin;
        const allowed = allowedOrigins.includes(parsed.origin);
        if (sameOrigin || allowed)
            return parsed.toString();
        if (parsed.protocol === 'https:')
            return parsed.toString();
        return null;
    }
    catch (error) {
        return null;
    }
}
//# sourceMappingURL=security.js.map