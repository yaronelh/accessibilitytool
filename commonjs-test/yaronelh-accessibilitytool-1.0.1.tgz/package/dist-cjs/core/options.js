"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.addDefaultIconOptions = addDefaultIconOptions;
exports.ensureModuleOrder = ensureModuleOrder;
exports.disableUnsupportedFeatures = disableUnsupportedFeatures;
exports.buildDefaultModuleOrder = buildDefaultModuleOrder;
const accessibility_interface_js_1 = require("../interfaces/accessibility.interface.js");
const icon_assets_js_1 = require("./icon-assets.js");
function addDefaultIconOptions(targetOptions, userOptions) {
    if (userOptions.icon?.closeIconElem)
        targetOptions.icon.closeIconElem = userOptions.icon.closeIconElem;
    if (userOptions.icon?.resetIconElem)
        targetOptions.icon.resetIconElem = userOptions.icon.resetIconElem;
    if (userOptions.icon?.imgElem)
        targetOptions.icon.imgElem = userOptions.icon.imgElem;
    if (!targetOptions.icon.closeIconElem) {
        targetOptions.icon.closeIconElem = (0, icon_assets_js_1.createDefaultCloseIcon)();
    }
    if (!targetOptions.icon.resetIconElem) {
        targetOptions.icon.resetIconElem = (0, icon_assets_js_1.createDefaultResetIcon)();
    }
    if (!targetOptions.icon.imgElem) {
        targetOptions.icon.imgElem = (0, icon_assets_js_1.createDefaultLauncherIcon)();
    }
}
function ensureModuleOrder(defaultOrder, modulesOrder) {
    defaultOrder.forEach((moduleOrder) => {
        if (!modulesOrder.find((existingOrder) => existingOrder.type === moduleOrder.type)) {
            modulesOrder.push(moduleOrder);
        }
    });
}
function disableUnsupportedFeatures(common, options) {
    if (!('webkitSpeechRecognition' in window) || location.protocol !== 'https:') {
        common.warn("speech to text isn't supported in this browser or in http protocol (https required)");
        options.modules.speechToText = false;
    }
    const windowAny = window;
    if (!windowAny.SpeechSynthesisUtterance || !windowAny.speechSynthesis) {
        common.warn("text to speech isn't supported in this browser");
        options.modules.textToSpeech = false;
    }
}
function buildDefaultModuleOrder() {
    const modulesOrder = [];
    const keys = Object.keys(accessibility_interface_js_1.AccessibilityModulesType);
    keys.forEach((key) => {
        const keyNum = parseInt(key);
        if (!isNaN(keyNum)) {
            modulesOrder.push({
                type: keyNum,
                order: keyNum
            });
        }
    });
    return modulesOrder;
}
//# sourceMappingURL=options.js.map