export declare function escapeCssString(value: string): string;
export declare function sanitizeDomAttribute(tagName: string, attrName: string, attrValue: unknown): string;
export declare function normalizeIframeUrl(url: string, allowedOrigins?: string[]): string;
