export declare function isActivationEvent(event: Event | KeyboardEvent): boolean;
export declare function getEventTarget<T extends HTMLElement>(event?: Event | null): T;
