import { IJsonToHtml } from '../interfaces/common.interface.js';
export declare function createDefaultLauncherIcon(): {
    type: string;
    attrs: {
        src: string;
        alt: string;
        'aria-hidden': string;
        class: string;
    };
};
export declare function createDefaultCloseIcon(): IJsonToHtml;
export declare function createDefaultResetIcon(): IJsonToHtml;
export declare function buildBuiltinActionIconCss(): string;
