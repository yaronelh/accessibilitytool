"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.isActivationEvent = isActivationEvent;
exports.getEventTarget = getEventTarget;
function isActivationEvent(event) {
    if (event.type === 'click')
        return true;
    if (!(event instanceof KeyboardEvent))
        return true;
    return event.key === 'Enter';
}
function getEventTarget(event) {
    return (event?.target ?? null);
}
//# sourceMappingURL=event-utils.js.map