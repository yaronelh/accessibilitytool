"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.saveSessionState = saveSessionState;
exports.restoreSessionState = restoreSessionState;
const SESSION_STORAGE_KEY = 'accessibility:session:v1';
const LEGACY_SESSION_STORAGE_KEY = '_accessState';
function saveSessionState(storage, sessionState) {
    storage.set(SESSION_STORAGE_KEY, sessionState);
    storage.remove(LEGACY_SESSION_STORAGE_KEY);
}
function restoreSessionState(storage, handlers) {
    const sessionState = (storage.get(SESSION_STORAGE_KEY) ??
        storage.get(LEGACY_SESSION_STORAGE_KEY));
    if (!sessionState)
        return;
    replayDelta(sessionState.textSize, handlers.applyTextSize);
    replayDelta(sessionState.textSpace, handlers.applyTextSpace);
    replayDelta(sessionState.lineHeight, handlers.applyLineHeight);
    if (sessionState.invertColors)
        handlers.enableInvertColors();
    if (sessionState.grayHues)
        handlers.enableGrayHues();
    if (sessionState.underlineLinks)
        handlers.enableUnderlineLinks();
    if (sessionState.bigCursor)
        handlers.enableBigCursor();
    if (sessionState.readingGuide)
        handlers.enableReadingGuide();
    handlers.assignSessionState(sessionState);
}
function replayDelta(value, apply) {
    if (!value)
        return;
    if (value > 0) {
        while (value--)
            apply(true);
    }
    else {
        while (value++)
            apply(false);
    }
}
//# sourceMappingURL=session.js.map