import { Storage } from '../storage.js';
import { ISessionState } from '../interfaces/accessibility.interface.js';
export declare function saveSessionState(storage: Storage, sessionState: ISessionState): void;
export declare function restoreSessionState(storage: Storage, handlers: {
    applyTextSize(isIncrease: boolean): void;
    applyTextSpace(isIncrease: boolean): void;
    applyLineHeight(isIncrease: boolean): void;
    enableInvertColors(): void;
    enableGrayHues(): void;
    enableUnderlineLinks(): void;
    enableBigCursor(): void;
    enableReadingGuide(): void;
    assignSessionState(sessionState: ISessionState): void;
}): void;
